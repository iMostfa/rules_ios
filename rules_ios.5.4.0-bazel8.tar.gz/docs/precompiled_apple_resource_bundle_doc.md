<!-- Generated with Stardoc: http://skydoc.bazel.build -->

This provides a resource bundle implementation that builds the resource bundle
only once
NOTE: This rule only exists because of this issue
https://github.com/bazelbuild/rules_apple/issues/319
if this is ever fixed in bazel it should be removed

<a id="precompiled_apple_resource_bundle"></a>

## precompiled_apple_resource_bundle

<pre>
load("@rules_ios//rules:precompiled_apple_resource_bundle.bzl", "precompiled_apple_resource_bundle")

precompiled_apple_resource_bundle(<a href="#precompiled_apple_resource_bundle-kwargs">kwargs</a>)
</pre>



**PARAMETERS**


| Name  | Description | Default Value |
| :------------- | :------------- | :------------- |
| <a id="precompiled_apple_resource_bundle-kwargs"></a>kwargs |  <p align="center"> - </p>   |  none |


